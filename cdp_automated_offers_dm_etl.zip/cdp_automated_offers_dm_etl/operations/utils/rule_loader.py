import json
import boto3
import os
from urllib.parse import urlparse

def load_rules_from_s3(s3_path_key: str, rules_file: str) -> dict:
    try:
        # Fallback for UAT testing without Airflow changes
        fallback_path = "s3://cdp-test-uat-infra/rules"
        base_path = os.getenv(s3_path_key, fallback_path)
        
        if not base_path:
            raise ValueError(f"Environment variable '{s3_path_key}' is not set.")

        full_path = f"{base_path.rstrip('/')}/{rules_file}"
        
        parsed_url = urlparse(full_path)
        bucket = parsed_url.netloc
        key = parsed_url.path.lstrip("/")

        s3 = boto3.client("s3")
        obj = s3.get_object(Bucket=bucket, Key=key)

        return json.loads(obj["Body"].read().decode("utf-8"))

    except Exception as e:
        raise RuntimeError(
            f"[RULE_ENGINE ERROR] Failed to load rules from S3. "
            f"key={s3_path_key}, file={rules_file}"
        ) from e