from pyspark.sql.functions import col, upper

def apply_rules(df, rules: dict):
    
    # 1. The Global Kill Switch (FATAL ERROR)
    # If the master "enabled" flag is false, we crash the job intentionally.
    # Returning `df` here would publish unfiltered, raw data.
    if not rules.get("enabled", True):
        raise RuntimeError(
            "[RULE_ENGINE FATAL] Rules are globally disabled in JSON (enabled: false). "
            "In a Configuration-Driven (Static SQL) architecture, bypassing rules would publish "
            "unfiltered raw data. Halting pipeline to prevent compliance breach."
        )

    # 2. Apply rules dynamically
    for rule in rules.get("rules", []):
        
        # --- NEW: Rule-Level Toggle ---
        # Allows the business to turn off specific rules without crashing the pipeline
        if not rule.get("enabled", True):
            print(f"[RULE_ENGINE] Skipping disabled rule for field: {rule.get('field')}")
            continue
        # ------------------------------

        field = rule["field"]
        op = rule["operator"]
        value = rule.get("value")

        if op == "IN":
            df = df.filter(col(field).isin(*value))
        elif op == "NOT IN":
            df = df.filter(~col(field).isin(*value))
        elif op == "=":
            df = df.filter(col(field) == value)
        elif op == "!=":
            df = df.filter(col(field) != value)
        
        # --- Case Insensitive Matches ---
        elif op == "= (IGNORE CASE)":
            df = df.filter(upper(col(field)) == value.upper())
        elif op == "!= (IGNORE CASE)":
            df = df.filter(upper(col(field)) != value.upper())

        # --- Mathematical Inequalities ---
        elif op == ">":
            df = df.filter(col(field) > value)
        elif op == ">=":
            df = df.filter(col(field) >= value)
        elif op == "<":
            df = df.filter(col(field) < value)
        elif op == "<=":
            df = df.filter(col(field) <= value)

        # --- Nulls, Between, Likes, and Regex ---
        elif op == "IS NULL":
            df = df.filter(col(field).isNull())
        elif op == "IS NOT NULL":
            df = df.filter(col(field).isNotNull())
        elif op == "BETWEEN":
            df = df.filter(col(field).between(value[0], value[1]))
        elif op == "LIKE" and value is not None:
            df = df.filter(col(field).like(value))
        elif op == "NOT LIKE" and value is not None:
            df = df.filter(~col(field).like(value))
        elif op == "RLIKE" and value is not None:
            df = df.filter(col(field).rlike(value))
        elif op == "NOT RLIKE" and value is not None:
            df = df.filter(~col(field).rlike(value))
        else:
            raise ValueError(f"Unsupported operator: {op}")

    return df